Amanita Ocean 0.24.0

Platform: macOS Apple Silicon (arm64), macOS 11.0 or later
Formats: VST3, Audio Unit, CLAP
Characters: Default, Bloom, Drift, Veil, Current, Fathom, Undertow, Spume

Install:
- Quit your DAW and double-click "Install Amanita Ocean.command".
  It installs the three plug-ins for your user account; see INSTALL.txt.
- Or paste this line into Terminal and press Return:
  curl -fsSL https://ocean.amanita.music/install-macos.sh | bash
- Or copy by hand:
  "Amanita Ocean.vst3" to ~/Library/Audio/Plug-Ins/VST3/
  "Amanita Ocean.component" to ~/Library/Audio/Plug-Ins/Components/
  "Amanita Ocean.clap" to ~/Library/Audio/Plug-Ins/CLAP/

Validation:
- DSP and state/UI test suites passed.
- Audio Unit validation passed (auval, 2026-10-10, on this binary).
- Official CLAP validator 0.3.2 ran 20 tests: 15 passed, 5 skipped,
  0 failed (one non-fatal cold scan-time warning).
- All bundles are ad-hoc signed for local installation and are not notarized.

Source commit: 3eefead
